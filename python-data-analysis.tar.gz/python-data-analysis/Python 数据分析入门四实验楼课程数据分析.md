# Python 数据分析入门四实验楼课程数据分析

# 内容简介

本实验主要使用实验楼课程数据来进行一次实战性质的时间序列分析。由于我们自己爬取到的课程数据类型有限，所以这里分用到的课程数据是实验楼内部导出来的数据。


## 数据概览

本次课程的数据来源于实验楼运行过程中产生的真实数据，我们对部分数据进行了脱敏处理。

首先，我们需要下载课程数据集 `courses.txt`。

```bash
wget http://labfile.oss.aliyuncs.com/courses/764/courses.txt
```
下载之后，可以通过 `head` 命令预览数据文件的前 10 行。
```bash
head -10 courses.txt
```
![此处输入图片的描述](https://dn-anything-about-doc.qbox.me/document-uid214893labid3471timestamp1505369719816.png/wm)

预览数据集，能让我们对数据结构，包含的大致内容有快速了解。这里，通过预览`courses.txt`，我们可以得到以下几条结论：

1. 是典型的通过**逗号分割**的文本数据集。
2. 数据集大致分为 `4` 列，且已经包含列名。
3. 数据集第 `1` 列为时间序列。
4. 数据集第 `2` 列为字符串类型。
5. 数据集第 `3，4` 列为数值类型。

总之，我们可以发现该数据集并不是特别复杂。

## 读取数据

了解数据集的类型之后，我们就可以开始读取数据，并对数据进行简单处理。当然，这里肯定会用到的就是 Pandas 数据处理开源工具了。

我们依旧通过实验楼线上提供的` ipython `终端来执行代码，线下练习推荐使用 `Jupyter Notebook`。

```bash
$ anaconda3/bin/ipython
```
进入 ipython 后，开始导入数据文件：

```python

In [1]: import pandas as pd

# 导入文本文件，使用逗号分割
In [2]: courses_ori = pd.read_table('courses.txt', sep=',', header=0)

# 预览 DataFrame 前 5 行
In [3]: courses_ori.head()
Out[3]:
              创建时间            课程名称    学习人数      学习时间
0  2013/5/13 10:55  Linux 基础入门（新版）  391962  23875374
1  2013/5/13 10:58          Vim编辑器  118629   2590047
2  2013/5/13 10:58      Python编程语言   51879   1189731
3  2013/5/13 10:59        Git 实战教程   93153   2109564
4  2013/5/13 11:06      MySQL 基础课程   78792   4229313
```

## 课程学习时间变化趋势

既然数据集中包含有时间，那么我们就可以做一个简单的时间序列分析，看一看课程学习人数和学习时间的随着时间的变化情况。

第一步当然是将时间数据变为 DatetimeIndex 格式，这样时间就可以作为索引了。

```python
In [4]: i = pd.to_datetime(courses_ori['创建时间'])

In [5]: i.head()
Out[5]:
0   2013-05-13 10:55:00
1   2013-05-13 10:58:00
2   2013-05-13 10:58:00
3   2013-05-13 10:59:00
4   2013-05-13 11:06:00
Name: 创建时间, dtype: datetime64[ns]

```

然后，我们对原始数据` courses_ori `进行修改。

```python

In [9]: courses_ts = pd.DataFrame(data=courses_ori.values, columns=courses_ori.columns, index=i)

In [10]: courses_ts.head()
Out[10]:
                                创建时间            课程名称    学习人数      学习时间
创建时间
2013-05-13 10:55:00  2013/5/13 10:55  Linux 基础入门（新版）  391962  23875374
2013-05-13 10:58:00  2013/5/13 10:58          Vim编辑器  118629   2590047
2013-05-13 10:58:00  2013/5/13 10:58      Python编程语言   51879   1189731
2013-05-13 10:59:00  2013/5/13 10:59        Git 实战教程   93153   2109564
2013-05-13 11:06:00  2013/5/13 11:06      MySQL 基础课程   78792   4229313

```
此时，我们成功将原创建时间修改为了 ` courses_ts ` 的时间戳索引。但是，原来的 创建时间 列依旧存在，需要将其去除。

```python
In [11]: courses_ts = courses_ts.drop("创建时间", axis=1)

In [12]: courses_ts.head()
Out[12]:
                               课程名称    学习人数      学习时间
创建时间
2013-05-13 10:55:00  Linux 基础入门（新版）  391962  23875374
2013-05-13 10:58:00          Vim编辑器  118629   2590047
2013-05-13 10:58:00      Python编程语言   51879   1189731
2013-05-13 10:59:00        Git 实战教程   93153   2109564
2013-05-13 11:06:00      MySQL 基础课程   78792   4229313

```

接下来，我们先看一看学习人数和学习时间随着时间变化的趋势。为了更方便绘图，我们可以进一步减少数据量，这里可以用 Pandas 对时间序列降采样。

这里，我们按照周次频率进行降采样。

```python
# 按照周次频率进行降采样
In [13]: courses_ts_W = courses_ts.resample('W').sum()
```
然后，我们使用 Matplotlib 对学习人数和学习时间随着时间变化的趋势进行绘图。

这里拿累计学习时间举例，尝试绘制折线图
```python
In [14]: import matplotlib.pyplot as plt

In [15]: plt.plot_date(courses_ts_W.index, courses_ts_W['学习时间'], '-')
In [16]: plt.xlabel('Time Series')
In [17]: plt.ylabel("Study Time")
In [18]: plt.show()
```
![此处输入图片的描述](https://dn-anything-about-doc.qbox.me/document-uid214893labid3471timestamp1505379982079.png/wm)

采用常用的` plt.plot() `或者 `plt.plot_date()` 绘制出的这张图看起来很糟糕，它似乎并不能很好地传达出实验课程累计学习时间的变化趋势。

这里，我们学习引入另一个绘图库 Seaborn，它是整合了 Matplotlib 核心方法的高级绘图库，

我们使用Seaborn 提供的 regplot 方法，它可以在绘制散点图时，对数据自动进行回归拟合。我们一起来看一下：


```python
# 使用 Seaborn 时，须同时引入 Matplotlib
In [19]: import matplotlib.pyplot as plt
In [20]: import seaborn as sns

# 新添加一个序数列，方便绘制散点图
In [21]: courses_ts_W['id'] = range(0,len(courses_ts_W.index.values))

In [22]: sns.regplot("id", "学习时间", data=courses_ts_W, scatter_kws={"s": 10}, order=8, ci=None, truncate=True)

In [23]: plt.xlabel('Time Series')
In [24]: plt.ylabel("Study Time")
In [25]: plt.show()
```
看起来比上面直接绘制折线图要好很多。但是，这条显示趋势的拟合线似乎依旧有一些问题。

![此处输入图片的描述](https://dn-anything-about-doc.qbox.me/document-uid214893labid3471timestamp1505380557453.png/wm)

一开始数据向下凹的厉害，以及最后的翘尾。重新查看数据，我们可以发现曲线下凹部分是由于实验楼在 2013 年的第二、第三季度新增课程较少。而尾部的上翘，应归结于拟合偏差，你可以通过减小 `order= `参数的数值，来降低这种偏差。

当然，我们还可以通过设置 `x_bins=` 参数，绘制出能更加直观反映上升或下降趋势的图像。

```python
In [26]: sns.regplot("id", "学习人数", data=courses_ts_W, x_bins=10)

In [27]: plt.xlabel('Time Series')
In [28]: plt.ylabel("Study Time")
In [29]: plt.show()
```
我们进一步降低了采样点，并得到了置信区间。这就能很清晰地反映出，课程累计实验时长随着时间推移在逐渐减少。

![此处输入图片的描述](https://dn-anything-about-doc.qbox.me/document-uid214893labid3471timestamp1505381104805.png/wm)

你可能会纳闷，课程累计实验时长为什么会逐渐减少？原因当然很简单，新课程出来之后，一开始学习的人数较少，累计学习的时间也比较少。而老课程时间的增加，尤其是很多年前的课程累计实验时间数值非常高。这也反映了，实验楼的课程质量经得住时间考验。

### 实验学习情况分析

既然我们有每门课程的总学习时间和学习人数，那么我们就能计算出每门课下，每个人的平均学习时间。

```python
# 每次做单独分析时，最好复制一份整理好的数据，减少对原数据集影响
In [30]: courses_ts_A = courses_ts.copy()

# 计算平均学习时间并添加列
In [31]: courses_ts_A['平均学习时间'] = courses_ts_A['学习时间']/courses_ts_A['学习人数']

# 预览
In [32]: courses_ts_A.head()
Out[32]:
创建时间        课程名称         学习人数      学习时间   平均学习时间
2013-05-13 10:55:00  Linux 基础入门（新版）  391962  23875374  60.9125
2013-05-13 10:58:00          Vim编辑器  118629   2590047  21.8332
2013-05-13 10:58:00      Python编程语言   51879   1189731  22.9328
2013-05-13 10:59:00        Git 实战教程   93153   2109564  22.6462
2013-05-13 11:06:00      MySQL 基础课程   78792   4229313  53.6769

```
我们可以依据平均时间对数据集进行排序，然后预览前 5 条和后 5 条数据：

```python
In [33]: courses_ts_A.sort_values(by='平均学习时间', ascending=False).head()
```
![此处输入图片的描述](https://dn-anything-about-doc.qbox.me/document-uid214893labid3471timestamp1505439696972.png/wm)

看以看出，平均学习时间较长的都是训练营课程，这也预料之中。因为训练营课程内容较多，所以平均学习时间自然较长。

查看后 5 条数据如下：
```python
In [34]: courses_ts_A.sort_values(by='平均学习时间', ascending=False).tail()
```
![此处输入图片的描述](https://dn-anything-about-doc.qbox.me/document-uid214893labid3471timestamp1505439701622.png/wm)

对于平均学习时间较短的这些数据。我们可以发现这些课程的共同特点，那就是可能没有添加在线实验环境，或者是在本地书写代码，在线提交结果的任务型课程。

如果我们进一步分析课程的异常情况，可以查看一些学习人数偏多，但平均时间明显偏少的课程。这里，需要计算学习人数与平均学习时间的比值：

```python
# 添加新列
In [35]: courses_ts_A['人数/平均学习时间'] = courses_ts_A['学习人数']/courses_ts_A['平均学习时间']

# 按照比值从小到大排序并显示前 10 条
In [36]: courses_ts_A.sort_values(by='人数/平均学习时间').head(10)
```
下图显示的是学习人数与平均学习时间比值最为悬殊的前 10 条数据。

![此处输入图片的描述](https://dn-anything-about-doc.qbox.me/document-uid214893labid3471timestamp1505441902743.png/wm)

排除第一条异常数据，以及第二条不需要太多操作的课程，我们可以发现剩下的课程大多都提供了线上环境。这些课程学习人数众多，但是平均学习时间少的可怜。对于这样的现状大致存在三种原因：

1. 实验有趣，但难度大、代码多。所以，很多用户快速地完成了从开机到放弃的过程。
2. 部分用户可能直接下载提供的完成代码文件，识别了一下色情图片或 2048 游戏，并未逐一手写代码实现。
3. 部分用户可能选择在本地 IDE 测试，没有被统计到时间。

实验楼后续可能会针对这些选题有趣的实验进行优化，避免大家只是玩玩而并未真正地去手动实现。

另外，通过绘制出平均学习时间和学习人数的关系图，我们可以更直观地看出需要重点关注的课程。


```python
In [37]: sns.jointplot("平均学习时间", "学习人数", kind='scatter', data=courses_ts_A)

In [23]: plt.xlabel('Average Study Time')
In [24]: plt.ylabel("Number of Users")
In [38]: plt.show()
```
对于靠近坐标轴的数据，都是我们需要重点关注的课程。

![此处输入图片的描述](https://dn-anything-about-doc.qbox.me/document-uid214893labid3471timestamp1505444326481.png/wm)


## 实验总结

本次实验，我们通过对实验楼课程数据集进行分析，简单的探索了课程之间的联系。通过实验，我们进一步熟悉前面课程提到的内容。